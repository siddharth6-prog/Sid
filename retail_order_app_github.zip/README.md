
# RetailEase

RetailEase is a mobile app built using Flutter to manage retail business orders. It includes:

- User login
- Product catalog
- Add to cart
- Cart review screen

## Getting Started

To run this project:

1. Install [Flutter](https://flutter.dev/docs/get-started/install)
2. Clone the repository or unzip this file
3. Run:

```bash
flutter pub get
flutter run
```
