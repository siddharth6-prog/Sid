
// Flutter app for retail business orders with cart and login
import 'package:flutter/material.dart';

void main() {
  runApp(RetailEaseApp());
}

class RetailEaseApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RetailEase',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('RetailEase', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.teal)),
            SizedBox(height: 20),
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage()));
              },
              child: Text('Login'),
            )
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<String> cart = [];

  void addToCart(String item) {
    setState(() {
      cart.add(item);
    });
  }

  void goToCart() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CartPage(cart: cart),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Products'),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: goToCart,
          )
        ],
      ),
      body: ListView(
        children: [
          ProductTile(title: 'Shirt', price: 19.99, onAdd: addToCart),
          ProductTile(title: 'Pants', price: 29.99, onAdd: addToCart),
          ProductTile(title: 'Shoes', price: 49.99, onAdd: addToCart),
        ],
      ),
    );
  }
}

class ProductTile extends StatelessWidget {
  final String title;
  final double price;
  final Function(String) onAdd;

  ProductTile({required this.title, required this.price, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(title),
      subtitle: Text('\$${price.toStringAsFixed(2)}'),
      trailing: ElevatedButton(
        child: Text('Add to Cart'),
        onPressed: () {
          onAdd(title);
        },
      ),
    );
  }
}

class CartPage extends StatelessWidget {
  final List<String> cart;

  CartPage({required this.cart});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Your Cart')),
      body: ListView.builder(
        itemCount: cart.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(cart[index]),
          );
        },
      ),
    );
  }
}
